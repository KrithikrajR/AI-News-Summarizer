import os
import datetime
from typing import List, Dict, Any, Optional

from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
import requests
from openai import OpenAI

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
NEWS_API_KEY = os.getenv("NEWS_API_KEY")

if not OPENAI_API_KEY:
    raise RuntimeError("Missing OPENAI_API_KEY. Put it in .env")
if not NEWS_API_KEY:
    raise RuntimeError("Missing NEWS_API_KEY. Put it in .env")

client = OpenAI(api_key=OPENAI_API_KEY)

app = Flask(__name__)

NEWSAPI_TOP = "https://newsapi.org/v2/top-headlines"
NEWSAPI_EVERYTHING = "https://newsapi.org/v2/everything"


def fetch_news(
    q: Optional[str],
    category: Optional[str],
    country: Optional[str],
    language: Optional[str],
    page_size: int = 8,
) -> List[Dict[str, Any]]:
    """
    Fetch news from NewsAPI. If `q` is provided, uses /everything (supports `language`).
    Otherwise uses /top-headlines (prefers `country` and `category`).
    """
    headers = {"X-Api-Key": NEWS_API_KEY}

    if q:
        params = {
            "q": q,
            "pageSize": page_size,
            "sortBy": "publishedAt",
        }
        if language:
            params["language"] = language
        url = NEWSAPI_EVERYTHING
    else:
        params = {"pageSize": page_size}
        if country:
            params["country"] = country
        if category:
            params["category"] = category
        url = NEWSAPI_TOP

    r = requests.get(url, params=params, headers=headers, timeout=20)
    r.raise_for_status()
    data = r.json()
    return data.get("articles", [])


def summarize_text(text: str, target_lang: str, max_bullets: int = 3) -> str:
    """
    Summarize `text` and return the summary directly in the requested `target_lang`.
    Uses OpenAI Chat Completions (gpt-4o-mini for speed/cost).
    """
    if not text.strip():
        return ""

    system_prompt = (
        "You are a concise news summarizer. Return only the summary, no preface.\n"
        f"Language: {target_lang}\n"
        f"Style: {max_bullets} short bullet points; neutral, fact-focused."
    )

    user_prompt = (
        "Summarize the following article content IN THE TARGET LANGUAGE.\n"
        "Keep names, numbers, locations exact. Remove speculation and ads.\n\n"
        f"ARTICLE:\n{text}"
    )

    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        temperature=0.2,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    )
    return resp.choices[0].message.content.strip()


def safe_join_text(article: Dict[str, Any]) -> str:
    pieces = []
    for k in ("title", "description", "content"):
        v = article.get(k) or ""
        if v and v not in pieces:
            pieces.append(v)
    return "\n\n".join(pieces)


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/summarize_news")
def api_summarize_news():
    payload = request.get_json(silent=True) or {}
    q = (payload.get("q") or "").strip()
    category = (payload.get("category") or "").strip() or None
    country = (payload.get("country") or "").strip() or os.getenv("DEFAULT_COUNTRY", "in")
    language = (payload.get("language") or "").strip() or None  # input article language for /everything
    target_lang = (payload.get("target_lang") or "en").strip()
    page_size = int(payload.get("pageSize") or os.getenv("DEFAULT_PAGE_SIZE", 8))
    page_size = max(1, min(page_size, 12))

    try:
        articles = fetch_news(q=q or None, category=category, country=country, language=language, page_size=page_size)
    except Exception as e:
        return jsonify({"ok": False, "error": f"News fetch failed: {e}"}), 400

    results = []
    for a in articles:
        raw_text = safe_join_text(a)
        try:
            summary = summarize_text(raw_text, target_lang=target_lang, max_bullets=3) if raw_text else ""
        except Exception as e:
            summary = f"(Summarization error: {e})"

        results.append({
            "title": a.get("title"),
            "source": (a.get("source") or {}).get("name"),
            "url": a.get("url"),
            "image": a.get("urlToImage"),
            "publishedAt": a.get("publishedAt"),
            "summary": summary,
        })

    return jsonify({"ok": True, "count": len(results), "items": results})


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=True)
