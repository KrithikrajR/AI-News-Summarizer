// ===== Utilities =====
const $ = (sel) => document.querySelector(sel);
const results = $("#results");
const voiceSelect = $("#voiceSelect");
const rate = $("#rate");
const pitch = $("#pitch");
const volume = $("#volume");
const rateVal = $("#rateVal");
const pitchVal = $("#pitchVal");
const volVal = $("#volVal");
let voices = [];
let currentUtterance = null;

// Load voices (async on some browsers)
function loadVoices() {
  voices = window.speechSynthesis.getVoices();
  voiceSelect.innerHTML = "";
  voices.forEach((v, i) => {
    const opt = document.createElement("option");
    opt.value = i;
    opt.textContent = `${v.name} — ${v.lang}`;
    voiceSelect.appendChild(opt);
  });
  // Try to auto-select Samantha (popular on Apple) if present
  const idx = voices.findIndex(v => /samantha/i.test(v.name));
  if (idx >= 0) voiceSelect.value = idx;
}
loadVoices();
if (typeof speechSynthesis !== "undefined") {
  speechSynthesis.onvoiceschanged = loadVoices;
}

// Sliders display
rate.addEventListener("input", () => (rateVal.textContent = rate.value));
pitch.addEventListener("input", () => (pitchVal.textContent = pitch.value));
volume.addEventListener("input", () => (volVal.textContent = volume.value));

// ===== TTS =====
function speak(text) {
  window.speechSynthesis.cancel();
  currentUtterance = new SpeechSynthesisUtterance(text);
  const v = voices[parseInt(voiceSelect.value, 10)];
  if (v) currentUtterance.voice = v;
  currentUtterance.rate = parseFloat(rate.value);
  currentUtterance.pitch = parseFloat(pitch.value);
  currentUtterance.volume = parseFloat(volume.value);
  window.speechSynthesis.speak(currentUtterance);
}
function stopAll() {
  window.speechSynthesis.cancel();
  currentUtterance = null;
}
$("#stopAllBtn").addEventListener("click", stopAll);

// ===== Render helpers =====
function cardSkeleton() {
  const div = document.createElement("div");
  div.className = "card p-4";
  div.innerHTML = `<div class="skeleton"></div>
    <div class="mt-3 space-y-2">
      <div class="h-4 bg-slate-200 rounded w-3/4"></div>
      <div class="h-3 bg-slate-200 rounded w-1/2"></div>
      <div class="h-3 bg-slate-200 rounded w-full"></div>
      <div class="h-3 bg-slate-200 rounded w-4/5"></div>
    </div>`;
  return div;
}
function renderArticles(items) {
  results.innerHTML = "";
  if (!items || !items.length) {
    results.innerHTML = `<div class="text-sm text-slate-500">No results.</div>`;
    return;
  }
  items.forEach(a => {
    const card = document.createElement("article");
    card.className = "card";
    const img = a.image || "https://picsum.photos/seed/news/800/450";
    const date = a.publishedAt ? new Date(a.publishedAt).toLocaleString() : "";
    card.innerHTML = `
      <img src="${img}" class="card-img" alt="cover">
      <div class="card-body">
        <h3 class="card-title">${a.title || "Untitled"}</h3>
        <div class="card-meta">${a.source ? a.source + " • " : ""}${date}</div>
        <pre class="card-summary">${a.summary || ""}</pre>
        <div class="flex gap-2">
          <a href="${a.url}" target="_blank" class="btn-secondary">Open</a>
          <button class="btn-primary speak">Speak</button>
          <button class="btn-secondary pause">Pause</button>
          <button class="btn-secondary resume">Resume</button>
          <button class="btn-secondary stop">Stop</button>
        </div>
      </div>`;

    const summaryEl = card.querySelector(".card-summary");
    card.querySelector(".speak").addEventListener("click", () => speak(summaryEl.textContent));
    card.querySelector(".pause").addEventListener("click", () => window.speechSynthesis.pause());
    card.querySelector(".resume").addEventListener("click", () => window.speechSynthesis.resume());
    card.querySelector(".stop").addEventListener("click", stopAll);

    results.appendChild(card);
  });
}

// ===== Form submit =====
$("#controls").addEventListener("submit", async (e) => {
  e.preventDefault();

  // Show placeholders
  results.innerHTML = "";
  for (let i = 0; i < 6; i++) results.appendChild(cardSkeleton());

  const payload = {
    q: $("#q").value.trim(),
    category: $("#category").value || null,
    country: $("#country").value || "in",
    pageSize: parseInt($("#pageSize").value || "8", 10),
    target_lang: $("#targetLang").value || "en"
  };

  try {
    const r = await fetch("/api/summarize_news", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await r.json();
    if (!data.ok) throw new Error(data.error || "Unknown error");
    renderArticles(data.items);
  } catch (err) {
    results.innerHTML = `<div class="text-sm text-red-600">Error: ${err.message}</div>`;
  }
});
