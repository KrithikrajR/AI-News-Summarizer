# AI News Summarizer (Multi-language + Multi-Voice)

A ready-to-run web app that fetches live news, summarizes with OpenAI, translates into your chosen language, and reads summaries aloud using your device's voices (Web Speech API).

## Features
- Live news from NewsAPI (query/category/country/language)
- AI summarization with OpenAI
- Output language selection (supports any language code)
- Attractive Tailwind UI
- Multiple voices (actor/actress) via browser SpeechSynthesis (e.g., *Samantha* on Apple)
- Play/Pause/Resume/Stop + rate/pitch/volume controls
- Mobile-friendly

## 1) Prerequisites
- Python 3.9+
- Create free API keys: 
  - OpenAI API Key: https://platform.openai.com
  - NewsAPI Key: https://newsapi.org

## 2) Setup
```bash
cd ai-news-summarizer
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# open .env and paste your keys
```

## 3) Run
```bash
python app.py
# open http://127.0.0.1:5000
```

## 4) Deploy (quick ideas)
- Render/Heroku/Fly.io: set the same env vars and run `python app.py`
- Or use a proper WSGI server (gunicorn) behind a reverse proxy

## 5) Common Issues
- **Voices list empty?** Some browsers load voices asynchronously; wait ~1–2s or reload. Mobile browsers may have fewer voices.
- **`ModuleNotFoundError`**: Re-run `pip install -r requirements.txt` inside the virtualenv.
- **`401 Unauthorized`**: Check your API keys in `.env`.
- **No audio on iOS**: User interaction required before playback; tap the play button first.

## 6) Customize
- Add categories, tweak card layout in `templates/index.html`
- Change summarization style in `app.py > summarize_text()`
- Add caching or a DB if needed

Enjoy!
